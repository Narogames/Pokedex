import Pokedex from './components/Pokedex'
import './App.css'

function App() {


  return (
    <>
      <Pokedex/>
    </>
  )
}

export default App
